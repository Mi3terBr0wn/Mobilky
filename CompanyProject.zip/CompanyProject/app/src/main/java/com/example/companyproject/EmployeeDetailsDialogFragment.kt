package com.example.companyproject

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.annotation.RequiresApi

class EmployeeDetailsDialogFragment: android.app.DialogFragment() {
    private val exceptionTag = "EmpDetailsDialogFrag"

    interface OnInputListenerSortId {
        fun sendInputSortId(sortId: Int)
    }

    lateinit var onInputListenerSortId: OnInputListenerSortId

    private lateinit var textViewFullName: TextView
    private lateinit var textViewYearOfBirth: TextView
    private lateinit var textViewPosition: TextView
    private lateinit var textViewHireDate: TextView
    private lateinit var textViewEmployment: TextView
    private lateinit var textViewPhoneNumber: TextView
    private lateinit var textViewEmail: TextView
    private lateinit var textViewPassportNumber: TextView
    private lateinit var textViewInn: TextView
    private lateinit var textViewSalary: TextView
    private lateinit var textViewCommission: TextView
    private lateinit var buttonDel: Button
    private lateinit var buttonEdit: Button
    private lateinit var buttonOk: Button

    private var currentIdForSort: Int = -1

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        val view: View = inflater!!.inflate(R.layout.employee_details, container, false)
        textViewFullName = view.findViewById(R.id.textViewFullName)
        textViewYearOfBirth = view.findViewById(R.id.textViewYearOfBirth)
        textViewPosition = view.findViewById(R.id.textViewPosition)
        textViewHireDate = view.findViewById(R.id.textViewHireDate)
        textViewEmployment = view.findViewById(R.id.textViewEmployment)
        textViewPhoneNumber = view.findViewById(R.id.textViewPhoneNumber)
        textViewEmail = view.findViewById(R.id.textViewEmail)
        textViewPassportNumber = view.findViewById(R.id.textViewPassportNumber)
        textViewInn = view.findViewById(R.id.textViewInn)
        textViewSalary = view.findViewById(R.id.textViewSalary)
        textViewCommission = view.findViewById(R.id.textViewCommission)
        buttonDel = view.findViewById(R.id.button_details_delete)
        buttonEdit = view.findViewById(R.id.button_details_edit)
        buttonOk = view.findViewById(R.id.button_details_ok)

        textViewFullName.setOnLongClickListener { setSortId(0) }
        textViewYearOfBirth.setOnLongClickListener { setSortId(1) }
        textViewPosition.setOnLongClickListener { setSortId(2) }
        textViewHireDate.setOnLongClickListener { setSortId(3) }
        textViewEmployment.setOnLongClickListener { setSortId(4) }
        textViewPhoneNumber.setOnLongClickListener { setSortId(5) }
        textViewEmail.setOnLongClickListener { setSortId(6) }
        textViewPassportNumber.setOnLongClickListener { setSortId(7) }
        textViewInn.setOnLongClickListener { setSortId(8) }
        textViewSalary.setOnLongClickListener { setSortId(9) }
        textViewCommission.setOnLongClickListener { setSortId(10) }

        buttonDel.setOnClickListener { returnDel() }
        buttonEdit.setOnClickListener { returnEdit() }
        buttonOk.setOnClickListener { returnIdForSort() }

        val arguments: Bundle = getArguments()
        textViewFullName.text = arguments.getString("fullName")
        textViewYearOfBirth.text = arguments.getString("yearOfBirth")
        textViewPosition.text = arguments.getString("position")
        textViewHireDate.text = arguments.getString("hireDate")
        textViewEmployment.text = arguments.getString("employment")
        textViewPhoneNumber.text = arguments.getString("phoneNumber")
        textViewEmail.text = arguments.getString("email")
        textViewPassportNumber.text = arguments.getString("passportNumber")
        textViewInn.text = arguments.getString("inn")
        textViewSalary.text = arguments.getString("salary")
        textViewCommission.text = arguments.getString("commission")

        if (arguments.getString("connection") != "1") {
            buttonDel.isEnabled = false
            buttonEdit.isEnabled = false
        }

        return view
    }

    override fun onAttach(activity: Activity?) {
        super.onAttach(activity)
        try {
            onInputListenerSortId = getActivity() as OnInputListenerSortId
        } catch (e: ClassCastException) {
            Log.e(exceptionTag, "onAttach: ClassCastException: " + e.message)
        }
    }

    private fun setSortId(id: Int): Boolean {
        currentIdForSort = id
        return true
    }

    private fun returnIdForSort() {
        onInputListenerSortId.sendInputSortId(currentIdForSort)
        dialog.dismiss()
    }

    private fun returnDel() {
        currentIdForSort = 8
        returnIdForSort()
    }

    private fun returnEdit() {
        currentIdForSort = 9
        returnIdForSort()
    }
}