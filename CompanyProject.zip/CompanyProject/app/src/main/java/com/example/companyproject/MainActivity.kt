package com.example.companyproject

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.companyproject.databinding.ActivityMainBinding
import com.example.companyproject.forRecyclerView.CustomRecyclerAdapterForEmployees
import com.google.android.material.navigation.NavigationView
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Socket
import com.google.gson.GsonBuilder
import com.google.gson.Gson
import com.example.companyproject.forRecyclerView.RecyclerItemClickListener
import com.example.companyproject.iu.DbHelper
import com.example.companyproject.iu.DepartmentOperator
import com.example.companyproject.iu.Department
import com.example.companyproject.iu.Employee

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener,
    EmployeeDetailsDialogFragment.OnInputListenerSortId
{
    private val gsonBuilder = GsonBuilder()
    private val gson: Gson = gsonBuilder.create()
    private val serverIP = "192.168.0.137"
    private val serverPort = 6666
    private lateinit var connection: Connection
    private var connectionStage: Int = 0
    private lateinit var dbh: DbHelper
    private var dbVersion = 2
    private var startTime: Long = 0

    private lateinit var textViewDepartmentName: TextView
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var nv: NavigationView
    private lateinit var toolbar: androidx.appcompat.widget.Toolbar
    private lateinit var progressBar: ProgressBar
    private lateinit var recyclerViewEmployees: RecyclerView

    private val coperator: DepartmentOperator = DepartmentOperator()
    private var currentDepartmentID: Int = -1
    private var currentEmployeeID: Int = -1
    private var waitingForUpdate: Boolean = false

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.appBarMain.toolbar)

        textViewDepartmentName = findViewById(R.id.textViewDepartmentName)
        drawerLayout = binding.drawerLayout
        nv = binding.navView
        nv.setNavigationItemSelectedListener(this)
        toolbar = findViewById(R.id.toolbar)
        toolbar.apply { setNavigationIcon(R.drawable.img) }
        toolbar.setNavigationOnClickListener { drawerLayout.openDrawer(GravityCompat.START) }
        progressBar = findViewById(R.id.progressBar)
        recyclerViewEmployees = findViewById(R.id.recyclerViewEmployees)
        recyclerViewEmployees.visibility = View.INVISIBLE
        recyclerViewEmployees.layoutManager = LinearLayoutManager(this)

        recyclerViewEmployees.addOnItemTouchListener(
            RecyclerItemClickListener(
                recyclerViewEmployees,
                object: RecyclerItemClickListener.OnItemClickListener {
                    override fun onItemClick(view: View, position: Int) {
                        currentEmployeeID = position
                        val employeeDetails = EmployeeDetailsDialogFragment()
                        val tempEmployee = coperator.getEmployee(currentDepartmentID, currentEmployeeID)
                        val bundle = Bundle()
                        bundle.putString("fullName", tempEmployee.fullName)
                        bundle.putString("yearOfBirth", tempEmployee.yearOfBirth)
                        bundle.putString("position", tempEmployee.position)
                        bundle.putString("hireDate", tempEmployee.hireDate)
                        bundle.putString("employment", tempEmployee.employment.toString())
                        bundle.putString("phoneNumber", tempEmployee.phoneNumber.toString())
                        bundle.putString("email", tempEmployee.email)
                        bundle.putString("passportNumber", tempEmployee.passportNumber.toString())
                        bundle.putString("inn", tempEmployee.inn.toString())
                        bundle.putString("salary", tempEmployee.salary.toString())
                        bundle.putString("commission", tempEmployee.commission.toString())
                        bundle.putString("connection", connectionStage.toString())
                        employeeDetails.arguments = bundle
                        employeeDetails.show(fragmentManager, "MyCustomDialog")

                        val position: String = tempEmployee.position
                        val text: String = "Этот сотрудник занимает должность ${position}."
                        val toast = Toast.makeText(
                            applicationContext,
                            text,
                            Toast.LENGTH_LONG
                        )
                        toast.show()
                    }

                    override fun onItemLongClick(view: View, position: Int) {
                        if (connectionStage == 1) {
                            currentDepartmentID = position
                            val manager: FragmentManager = supportFragmentManager
                            val myDialogFragmentDelEmployee = MyDialogFragmentDelEmployee()
                            val bundle = Bundle()
                            bundle.putString(
                                "employee",
                                coperator.getEmployee(currentDepartmentID, currentEmployeeID).fullName
                            )
                            myDialogFragmentDelEmployee.arguments = bundle
                            myDialogFragmentDelEmployee.show(manager, "MyDialog")
                        } else {
                            val toast = Toast.makeText(
                                applicationContext,
                                "Приложение не в сети!",
                                Toast.LENGTH_LONG
                            )
                            toast.show()
                        }
                    }
                }
            )
        )
        dbh = DbHelper(this, "MyFirstDB", null, dbVersion)
        startTime = System.currentTimeMillis()
        connection = Connection(serverIP, serverPort, "{R}", this)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        if (currentDepartmentID != -1) {
            menu.getItem(0).isVisible = true
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.action_add) {
            val intent = Intent()
            intent.setClass(this, EditEmployeeActivity::class.java)
            intent.putExtra("action", 1)
            startActivityForResult(intent, 1)
        }
        return super.onOptionsItemSelected(item)
    }

    internal inner class Connection(
        private val SERVER_IP: String,
        private val SERVER_PORT: Int,
        private val refreshCommand: String,
        private val activity: Activity
    ) {
        private var outputServer: PrintWriter? = null
        private var inputServer: BufferedReader? = null
        var thread1: Thread? = null
        private var threadT: Thread? = null

        internal inner class Thread1Server : Runnable {
            override fun run()
            {
                val socket: Socket
                try {
                    socket = Socket(SERVER_IP, SERVER_PORT)
                    outputServer = PrintWriter(socket.getOutputStream())
                    inputServer = BufferedReader(InputStreamReader(socket.getInputStream()))
                    Thread(Thread2Server()).start()
                    sendDataToServer(refreshCommand)
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }

        internal inner class Thread2Server : Runnable {
            override fun run() {
                while (true) {

                    try {
                        val message = inputServer!!.readLine()
                        if (message != null)
                        {
                            activity.runOnUiThread { processingInputStream(message) }
                        } else {
                            thread1 = Thread(Thread1Server())
                            thread1!!.start()
                            return
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                }
            }
        }

        internal inner class Thread3Server(private val message: String) : Runnable
        {
            override fun run()
            {
                outputServer!!.write(message)
                outputServer!!.flush()
            }
        }

        internal inner class ThreadT : Runnable
        {
            override fun run() {
                while (true)
                {
                    if (System.currentTimeMillis() - startTime > 5000L && connectionStage == 0)
                    {
                        activity.runOnUiThread { val toast = Toast.makeText(
                            applicationContext,
                            "Подключиться не удалось!\n" +
                                    "Будут использоваться данные из локальной базы данных.",
                            Toast.LENGTH_LONG
                        )
                            toast.show() }
                        connectionStage = -1
                        progressBar.visibility = View.INVISIBLE
                        val tempArrayListDepartments: ArrayList<Department> = dbh.getAllData()
                        coperator.setDepartments(tempArrayListDepartments)
                        for (i in 0 until tempArrayListDepartments.size)
                        {
                            activity.runOnUiThread { nv.menu.add(0, i, 0,
                                tempArrayListDepartments[i].name as CharSequence) }
                        }


                    }
                }
            }
        }

        fun sendDataToServer(text: String)
        {
            Thread(Thread3Server(text + "\n")).start()
        }

        private fun processingInputStream(text: String)
        {
            dbh.removeAllData()
            val tempGo: DepartmentOperator = gson.fromJson(text, DepartmentOperator::class.java)
            for (i in tempGo.getDepartments())
            {
                dbh.insertDepartment(i)
            }

            if (connectionStage != 1)
            {
                val toast = Toast.makeText(
                    applicationContext,
                    "Успешно подключено!\n" +
                            "Будут использоваться данные, полученные от сервера.",
                    Toast.LENGTH_LONG
                )
                toast.show()
            }

            progressBar.visibility = View.INVISIBLE
            for (i in 0 until coperator.getDepartments().size)
            {
                nv.menu.removeItem(i)
            }
            val tempArrayListDepartments: ArrayList<Department> = dbh.getAllData()
            coperator.setDepartments(tempArrayListDepartments)
            for (i in 0 until tempArrayListDepartments.size)
            {
                nv.menu.add(
                    0, i, 0,
                    tempArrayListDepartments[i].name as CharSequence
                )
            }
            if (waitingForUpdate || connectionStage == -1)
            {
                waitingForUpdate = false
                if (currentDepartmentID != -1)
                {
                    recyclerViewEmployees.adapter = CustomRecyclerAdapterForEmployees(
                        coperator.getEmployeeNames(currentDepartmentID),
                        coperator.getYearOfBirth(currentDepartmentID)
                    )
                }
            }
            connectionStage = 1
        }

        init {
            thread1 = Thread(Thread1Server())
            thread1!!.start()
            threadT = Thread(ThreadT())
            threadT!!.start()
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        val tempString = "Отдел ${item.title}"
        textViewDepartmentName.text = tempString
        invalidateOptionsMenu()
        currentDepartmentID = item.itemId
        recyclerViewEmployees.adapter = CustomRecyclerAdapterForEmployees(coperator.getEmployeeNames(currentDepartmentID),
            coperator.getYearOfBirth(currentDepartmentID))
        recyclerViewEmployees.visibility = View.VISIBLE
        return true
    }

    fun delEmployee() {
        connection.sendDataToServer("d${currentDepartmentID}${currentEmployeeID}")
        waitingForUpdate = true
    }

    override fun sendInputSortId(sortId: Int) {
        var text: String = "Выбрана сортировка сотрудников по "
        when (sortId) {
            0 -> text += "ФИО."
            1 -> text += "году рождения."
            2 -> text += "должности."
            3 -> text += "дате найма."
            4 -> text += "рабочей ставке."
            5 -> text += "номеру телефона."
            6 -> text += "адресу электронной почты."
            7 -> text += "номеру паспорта."
            8 -> text += "номеру паспорта."
            9 -> text += "номеру ИНН."
            10 -> text += "размеру зарплаты."
            11 -> text += "размеру комиссионных."
            12 -> text = "Внимание! Изменения будут отправлены на сервер."
        }
        if (sortId != -1 && sortId != 8){
            val toast = Toast.makeText(
                applicationContext,
                text,
                Toast.LENGTH_LONG
            )
            toast.show()
        }
        if (sortId > -1 && sortId < 8) {
            coperator.sortEmployees(currentDepartmentID, sortId)
            if (connectionStage == 1) {
                connection.sendDataToServer("u" + gson.toJson(coperator))
            }
        }
        if (sortId == 8) {
            val manager: FragmentManager = supportFragmentManager
            val myDialogFragmentDelEmployee = MyDialogFragmentDelEmployee()
            val bundle = Bundle()
            bundle.putString("employee", coperator.getEmployee(currentEmployeeID, currentEmployeeID).fullName)
            myDialogFragmentDelEmployee.arguments = bundle
            myDialogFragmentDelEmployee.show(manager, "myDialog")
        }
        if (sortId == 9) {
            val tempEmployee = coperator.getEmployee(currentDepartmentID, currentEmployeeID)
            val intent = Intent()
            intent.setClass(this, EditEmployeeActivity::class.java)
            intent.putExtra("action", 2)
            intent.putExtra("fullName", tempEmployee.fullName)
            intent.putExtra("yearOfBirth", tempEmployee.yearOfBirth)
            intent.putExtra("position", tempEmployee.position)
            intent.putExtra("hireDate", tempEmployee.hireDate)
            intent.putExtra("employment", tempEmployee.employment.toString())
            intent.putExtra("phoneNumber", tempEmployee.phoneNumber.toString())
            intent.putExtra("phoneNumber", tempEmployee.phoneNumber)
            intent.putExtra("passportNumber", tempEmployee.passportNumber.toString())
            intent.putExtra("inn", tempEmployee.inn.toString())
            intent.putExtra("salary", tempEmployee.salary.toString())
            intent.putExtra("commission", tempEmployee.commission.toString())
            startActivityForResult(intent, 1)
        }
        recyclerViewEmployees.adapter = CustomRecyclerAdapterForEmployees (
            coperator.getEmployeeNames(currentDepartmentID),
            coperator.getYearOfBirth(currentDepartmentID))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            val action = data?.getSerializableExtra("action") as Int
            val fullName = data.getSerializableExtra("fullName") as String
            val yearOfBirth = data.getSerializableExtra("yearOfBirth") as String
            val position = data.getSerializableExtra("position") as String
            val hireDate = data.getSerializableExtra("hireDate") as String
            val employment = data.getSerializableExtra("employment") as Int
            val phoneNumber = data.getSerializableExtra("phoneNumber") as Int
            val email = data.getSerializableExtra("email") as String
            val passportNumber = data.getSerializableExtra("passportNumber") as Int
            val inn = data.getSerializableExtra("inn") as Int
            val salary = data.getSerializableExtra("salary") as Int
            val commission = data.getSerializableExtra("commission") as Int
            val tempEmployee = Employee(fullName, yearOfBirth, position,
                hireDate, employment, phoneNumber, email, passportNumber, inn, salary, commission)
            val tempEmployeeJSON: String = gson.toJson(tempEmployee)

            if (action == 1) {
                val tempStringToSend = "a${coperator.getDepartments()[currentDepartmentID].name}##$tempEmployeeJSON"
                connection.sendDataToServer(tempStringToSend)
                waitingForUpdate = true
            }
            if (action == 2) {
                val tempStringToSend = "e$currentDepartmentID.$currentEmployeeID##$tempEmployeeJSON"
                connection.sendDataToServer(tempStringToSend)
                waitingForUpdate = true
            }
        }
    }
}