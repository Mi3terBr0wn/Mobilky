package com.example.companyproject

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat

class EditEmployeeActivity : AppCompatActivity() {
    private lateinit var editFullName: EditText
    private lateinit var editYearOfBirth: EditText
    private lateinit var editPosition: EditText
    private lateinit var editHireDate: EditText
    private lateinit var editEmployment: EditText
    private lateinit var editPhoneNumber: EditText
    private lateinit var editEmail: EditText
    private lateinit var editCountPassportNumber: EditText
    private lateinit var editCountInn: EditText
    private lateinit var editCountSalary: EditText
    private lateinit var editCountCommission: EditText

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_employee)

        editFullName = findViewById(R.id.editTextFullName)
        editYearOfBirth = findViewById(R.id.editTextYearOfBirth)
        editPosition = findViewById(R.id.editTextPosition)
        editHireDate = findViewById(R.id.editTextHireDate)
        editEmployment = findViewById(R.id.editTextEmployment)
        editPhoneNumber = findViewById(R.id.editPhoneNumber)
        editEmail = findViewById(R.id.editTextEmail)
        editCountPassportNumber = findViewById(R.id.editTextPassportNumber)
        editCountInn = findViewById(R.id.editTextInn)
        editCountSalary = findViewById(R.id.editTextSalary)
        editCountCommission = findViewById(R.id.editTextCommission)

        val action = intent.getSerializableExtra("action") as Int

        findViewById<Button>(R.id.button_confirm).setOnClickListener { confirmChanges(action) }

        if (action == 2) {
            editFullName.setText(intent.getSerializableExtra("fullname") as String)
            editYearOfBirth.setText(intent.getSerializableExtra("yearofbirth") as String)
            editPosition.setText(intent.getSerializableExtra("position") as String)
            editHireDate.setText(intent.getSerializableExtra("hiredate") as String)
            editEmployment.setText(intent.getSerializableExtra("employment") as String)
            editPhoneNumber.setText(intent.getSerializableExtra("phonenumber") as String)
            editEmail.setText(intent.getSerializableExtra("email") as String)
            editCountPassportNumber.setText(intent.getSerializableExtra("passportnumber") as String)
            editCountInn.setText(intent.getSerializableExtra("inn") as String)
            editCountSalary.setText(intent.getSerializableExtra("salary") as String)
            editCountCommission.setText(intent.getSerializableExtra("commission") as String)
        }
    }

    private fun confirmChanges(action: Int) {
        if (editFullName.text.toString() != "" && editYearOfBirth.text.toString() != ""
            && editPosition.text.toString() != "" && editHireDate.text.toString() != ""
            && editEmployment.text.toString() != "" && editPhoneNumber.text.toString() != ""
            && editEmail.text.toString() != "" && editCountPassportNumber.text.toString() != ""
            && editCountInn.text.toString() != "" && editCountSalary.text.toString() != ""
            && editCountCommission.text.toString() != "")
        {
            val intent = Intent(this@EditEmployeeActivity,
                MainActivity::class.java)
            intent.putExtra("action", action)
            intent.putExtra("fullname", editFullName.text.toString().trim())
            intent.putExtra("yearofbirth", editYearOfBirth.text.toString().trim())
            intent.putExtra("position", editPosition.text.toString().trim())
            intent.putExtra("hiredate", editHireDate.text.toString().trim())
            intent.putExtra("employment", editEmployment.text.toString().trim().toInt())
            intent.putExtra("phonenumber", editPhoneNumber.text.toString().trim())
            intent.putExtra("email", editEmail.text.toString().trim())
            intent.putExtra("passportnumber", editCountPassportNumber.text.toString().trim().toInt())
            intent.putExtra("inn", editCountInn.text.toString().trim().toInt())
            intent.putExtra("salary", editCountSalary.text.toString().trim().toInt())
            intent.putExtra("commission", editCountCommission.text.toString().trim().toInt())

                setResult(RESULT_OK, intent)
                finish()
        } else {
            val toast = Toast.makeText(
                applicationContext,
                "Заполните обязательные поля!",
                Toast.LENGTH_SHORT
            )
            toast.show()
        }
    }

    @SuppressLint("SimpleDateFormat")
    private fun isDateValid(date: String?): Boolean {
        val myFormat = SimpleDateFormat("dd.MM.yyyy")
        myFormat.isLenient = false
        return try {
            if (date != null) {
                myFormat.parse(date)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}