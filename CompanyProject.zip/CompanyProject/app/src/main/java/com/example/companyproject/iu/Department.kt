package com.example.companyproject.iu

data class Department (
    val name: String,
    var listOfEmployees: ArrayList<Employee> = ArrayList()
)