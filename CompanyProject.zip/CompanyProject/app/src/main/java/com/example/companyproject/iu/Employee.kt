package com.example.companyproject.iu

data class Employee (
    val fullName: String,
    val yearOfBirth: String,
    val position: String,
    val hireDate: String,
    val employment: Int,
    val phoneNumber: Int,
    val email: String,
    val passportNumber: Int,
    val inn: Int,
    val salary: Int,
    val commission: Int,
)
