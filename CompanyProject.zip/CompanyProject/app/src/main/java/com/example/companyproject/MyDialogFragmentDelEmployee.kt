package com.example.companyproject

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment

class MyDialogFragmentDelEmployee: DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val arguments: Bundle? = arguments
        val employeeName = arguments?.getString("employee")
        val builder = AlertDialog.Builder(activity)
        builder.setMessage("Будет удален сотрудник: $employeeName")
            .setTitle("Внимание!")
            .setPositiveButton("Продолжить")
            { _, _ -> (activity as MainActivity?)?.delEmployee() }
            .setNegativeButton("Отмена") { _, _ -> }
        return builder.create()
    }
}