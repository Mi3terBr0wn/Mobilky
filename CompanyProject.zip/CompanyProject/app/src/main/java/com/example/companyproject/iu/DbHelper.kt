package com.example.companyproject.iu

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DbHelper(
    context: Context?,
    name: String?,
    factory: SQLiteDatabase.CursorFactory?,
    version: Int
) : SQLiteOpenHelper(context, name, factory, version) {

    private val table1Name = "DEPARTMENTS"
    private val col11 = "id"
    private val col12 = "name"
    private val createTable1 = "CREATE TABLE IF NOT EXISTS $table1Name" +
            "($col11 INTEGER PRIMARY KEY AUTOINCREMENT, $col12 TEXT);"
    private val dropTable1 = "DROP TABLE IF EXISTS $table1Name"

    private val table2Name = "EMPLOYEES"
    private val col21 = "id"
    private val col22 = "department_id"
    private val col23 = "full_name"
    private val col24 = "year_of_birth"
    private val col25 = "position"
    private val col26 = "hire_date"
    private val col27 = "employment"
    private val col28 = "phone_number"
    private val col29 = "email"
    private val col210 = "passport_number"
    private val col211 = "inn"
    private val col212 = "salary"
    private val col213 = "commission"

    private val createTable2 = "CREATE TABLE IF NOT EXISTS $table2Name " +
            "($col21 INTEGER PRIMARY KEY AUTOINCREMENT," +
            "$col22 INTEGER, $col23 TEXT, $col24 TEXT, $col25 TEXT," +
            "$col26 TEXT, $col27 INTEGER, $col28 INTEGER, $col29 TEXT, $col210 INTEGER, " +
            "$col211 INTEGER, $col212 INTEGER, $col213 INTEGER);"
    private val dropTable2 = "DROP TABLE IF EXISTS $table2Name"



    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(createTable1)
        db?.execSQL(createTable2)





    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL(dropTable1)
        db?.execSQL(dropTable2)
        onCreate(db)
    }

    fun insertDepartment(department: Department): Int {
        var forReturn = 0
        val db = this.writableDatabase
        //костыль на костылях
        val cv1 = ContentValues()
        val cv2 = ContentValues()
        cv1.put(table1Name, "Продажи")

        cv2.put(col22, 1)
        cv2.put(col23, "Петя Петя Петя")
        cv2.put(col24, "1998")
        cv2.put(col25, "менеджер")
        cv2.put(col26, "11.11.2011")
        cv2.put(col27, "2")
        cv2.put(col28, "1111111111")
        cv2.put(col29, "q@q.q")
        cv2.put(col210, "11112323")
        cv2.put(col211, "231223432")
        cv2.put(col212, "10000")
        cv2.put(col213, "50")
        var result = db.insert(table1Name, null, cv1)
        result = db.insert(table2Name, null, cv2)


        //val cv1 = ContentValues()
        cv1.put(col12, department.name)
        result = db.insert(table1Name, null, cv1)
        if (result != -1L) {
            forReturn = 1000
        }
        val name: String = department.name
        val selection: String = "name =?"
        val selectionArgs: Array<String> = arrayOf(department.name)
        val cursor: Cursor = db.query(table1Name, arrayOf(col11), selection,
            selectionArgs, null, null, null)

        cursor.moveToFirst()
        val index = cursor.getColumnIndex(col11)
        var departmentId: Int = -10
        if (index >= 0) {
            departmentId = cursor.getInt(index)
        }
        cursor.close()
        for (i in department.listOfEmployees) {
            val cv2 = ContentValues()
            cv2.put(col22, departmentId)
            cv2.put(col23, i.fullName)
            cv2.put(col24, i.yearOfBirth)
            cv2.put(col25, i.position)
            cv2.put(col26, i.hireDate)
            cv2.put(col27, i.employment)
            cv2.put(col28, i.phoneNumber)
            cv2.put(col29, i.email)
            cv2.put(col210, i.passportNumber)
            cv2.put(col211, i.inn)
            cv2.put(col212, i.salary)
            cv2.put(col213, i.commission)
            result = db.insert(table2Name, null, cv2)
            if (result != -1L) {
                forReturn++
            }
        }
        return forReturn
    }

    @SuppressLint("Range")
    fun getAllData(): ArrayList<Department> {
        val arrayListForReturn: ArrayList<Department> = ArrayList()
        val db = this.writableDatabase

        val cursor1: Cursor = db.query(table1Name, null, null,
            null, null, null, null)
        cursor1.moveToFirst()
        while (!cursor1.isAfterLast) {
            val tempArrayListForEmployee: ArrayList<Employee> = ArrayList()
            val index = cursor1.getColumnIndex(col11)
            var departmentId: Int = -10
            if (index >= 0) {
                departmentId = cursor1.getInt(index)
            }
            val cursor2: Cursor = db.query(table2Name, arrayOf(col22, col23, col24, col25, col26,
                col27, col28, col29, col210, col211, col212, col213), "$col22 = $departmentId",
                null, null, null, null)
            cursor2.moveToFirst()
            while (!cursor2.isAfterLast) {
                tempArrayListForEmployee.add(
                    Employee(
                    cursor2.getString(cursor2.getColumnIndex(col23)),
                    cursor2.getString(cursor2.getColumnIndex(col24)),
                    cursor2.getString(cursor2.getColumnIndex(col25)),
                    cursor2.getString(cursor2.getColumnIndex(col26)),
                    cursor2.getInt(cursor2.getColumnIndex(col27)),
                    cursor2.getInt(cursor2.getColumnIndex(col28)),
                    cursor2.getString(cursor2.getColumnIndex(col29)),
                    cursor2.getInt(cursor2.getColumnIndex(col210)),
                    cursor2.getInt(cursor2.getColumnIndex(col211)),
                    cursor2.getInt(cursor2.getColumnIndex(col212)),
                    cursor2.getInt(cursor2.getColumnIndex(col213))
                )
                )
                cursor2.moveToNext()
            }
            arrayListForReturn.add(
                Department(cursor1.getString(cursor1.getColumnIndex(col12)),
                tempArrayListForEmployee
            )
            )
            cursor2.close()
            cursor1.moveToNext()
        }
        cursor1.close()
        return arrayListForReturn

    }

    fun removeAllData() {
        val db = this.writableDatabase
        db.delete(table1Name, null, null)
        db.delete(table2Name, null, null)
    }


}