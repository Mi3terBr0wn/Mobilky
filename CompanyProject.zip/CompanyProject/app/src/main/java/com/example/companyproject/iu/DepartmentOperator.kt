package com.example.companyproject.iu

import java.util.*
import kotlin.collections.ArrayList

class DepartmentOperator {
    private var departments: ArrayList<Department> = ArrayList()

    fun getDepartments(): ArrayList<Department> {
        return departments
    }

    fun setDepartments(newDepartments: ArrayList<Department>) {
        departments = newDepartments
    }

    fun getEmployeeNames(indexDepartment: Int): ArrayList<String> {
        val arrayListForReturn: ArrayList<String> = ArrayList()
        for (i in departments[indexDepartment].listOfEmployees) {
            arrayListForReturn.add(i.fullName)
        }
        return arrayListForReturn
    }

    fun getYearOfBirth(indexDepartment: Int): ArrayList<String> {
        val arrayListForReturn: ArrayList<String> = ArrayList()
        for (i in departments[indexDepartment].listOfEmployees) {
            arrayListForReturn.add(i.yearOfBirth)
        }
        return arrayListForReturn
    }

    fun getEmployee(indexDepartment: Int, indexEmployee: Int): Employee {
        return departments[indexDepartment].listOfEmployees[indexEmployee]
    }

    fun sortEmployees(indexDepartment: Int, sortIndex: Int) {
        val tempArrayListOfEmployee: ArrayList<Employee> = ArrayList()
        val tempArrayListOfColumnString: ArrayList<String> = ArrayList()
        val tempArrayListOfColumnInt: ArrayList<Int> = ArrayList()
        val tempArrayListOfDate: ArrayList<GregorianCalendar> = ArrayList()

        for (i in departments[indexDepartment].listOfEmployees) {
            when (sortIndex) {
                0 -> tempArrayListOfColumnString.add(i.fullName.lowercase(Locale.ROOT))
                1 -> tempArrayListOfColumnString.add(i.yearOfBirth.lowercase(Locale.ROOT))
                2 -> tempArrayListOfColumnString.add(i.position.lowercase(Locale.ROOT))
                3 -> tempArrayListOfColumnString.add(i.hireDate.lowercase(Locale.ROOT))
                4 -> tempArrayListOfColumnInt.add(i.employment)
                5 -> tempArrayListOfColumnInt.add(i.phoneNumber)
                6 -> tempArrayListOfColumnString.add(i.email.lowercase(Locale.ROOT))
                7 -> tempArrayListOfColumnInt.add(i.passportNumber)
                8 -> tempArrayListOfColumnInt.add(i.inn)
                9 -> tempArrayListOfColumnInt.add(i.salary)
                10 -> tempArrayListOfColumnInt.add(i.commission)
            }
        }
        if (sortIndex != 4 && sortIndex != 5 && sortIndex != 7 && sortIndex != 8
            && sortIndex != 9 && sortIndex != 10) {
            tempArrayListOfColumnString.sort()

            for (i in tempArrayListOfColumnString) {
                for (j in departments[indexDepartment].listOfEmployees) {
                    var tempField: String = ""

                    when (sortIndex) {
                        0 -> tempField = j.fullName.lowercase(Locale.ROOT)
                        1 -> tempField = j.yearOfBirth.lowercase(Locale.ROOT)
                        2 -> tempField = j.position.lowercase(Locale.ROOT)
                        3 -> tempField = j.hireDate.lowercase(Locale.ROOT)
                        6 -> tempField = j.email.lowercase(Locale.ROOT)
                    }

                    if (i == tempField && !tempArrayListOfEmployee.contains(j)) {
                        tempArrayListOfEmployee.add(j)
                        break
                    }
                }
            }
            departments[indexDepartment].listOfEmployees = tempArrayListOfEmployee
        } else if (sortIndex == 4 || sortIndex == 5 || sortIndex == 7 || sortIndex == 8
            || sortIndex == 9 || sortIndex == 10) {
            tempArrayListOfColumnInt.sort()

            for (i in tempArrayListOfColumnInt) {
                for (j in departments[indexDepartment].listOfEmployees) {
                    var tempField: Int = -10

                    when (sortIndex) {
                        4 -> tempField = j.employment
                        5 -> tempField = j.phoneNumber
                        7 -> tempField = j.passportNumber
                        8 -> tempField = j.inn
                        9 -> tempField = j.salary
                        10 -> tempField = j.commission
                    }

                    if (i == tempField && !tempArrayListOfEmployee.contains(j)) {
                        tempArrayListOfEmployee.add(j)
                        break
                    }
                }
            }
            departments[indexDepartment].listOfEmployees = tempArrayListOfEmployee
        } else {
            tempArrayListOfDate.sort()


            departments[indexDepartment].listOfEmployees = tempArrayListOfEmployee
        }
    }

}